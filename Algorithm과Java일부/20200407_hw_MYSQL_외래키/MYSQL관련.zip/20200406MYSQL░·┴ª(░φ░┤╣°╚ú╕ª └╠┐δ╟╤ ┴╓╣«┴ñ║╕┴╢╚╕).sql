CREATE database HW2;

USE HW2;

show tables;

create table if not exists `customer` (
	`cusnum` int(11) not null,
    `cusname` varchar(11) default null,
    `cusaddr` varchar(30) default null,
    `cuscall1` varchar(15) default null,
	`cuscall2` varchar(15) default null,
    PRIMARY KEY (`cusnum`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `customer` (cusnum, `cusname`, `cusaddr`,`cuscall1`,`cuscall2` ) VALUES
(1, '사나', '서울','01011112222','023312524'),
(2, '설현', '대구','01033332222','023312524'),
(3, '정연', '부산','01044447777','023312524'),
(4, '모모', '교토','01074253697','08213567'),
(5, '아이유', '서울','01012345678','023393245');

create table if not exists `product` (
	`pcode` varchar(15) not null,
    `pname` varchar(15) default null,
    `pprice` int(30) default null,
    `pcount` int(10) default null,
    PRIMARY KEY (`pcode`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `product` (`pcode`, `pname`, pprice,pcount ) VALUES
('C1', 'BALENCIAGA티셔츠', 600000,2),
('S1', 'VALENTINO어글리슈즈', 800000,2),
('B1', 'CHANEL클러치', 1500000,1),
('S2', 'GOLDENGOOSE스니커즈', 400000,1);


CREATE TABLE IF NOT EXISTS `ORDERS` (
  `ORDERNO` int(11) NOT NULL,
  `ORDERPRICE` int(30) default NULL,
  `PAYCHECK` varchar(13) DEFAULT NULL,
  `DELIVERCK` varchar(13) DEFAULT NULL,
  `cusnum` int(11) DEFAULT NULL,
  `pcode` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`ORDERNO`),
  FOREIGN KEY (`cusnum`) REFERENCES `customer` (`cusnum`) on delete set null on update cascade,
  FOREIGN KEY (`pcode`) REFERENCES `product` (`pcode`) on delete set null on update cascade
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP table orders;
INSERT INTO `ORDERS` (ORDERNO, ORDERPRICE, `PAYCHECK`,`DELIVERCK`,`cusnum`,`pcode` ) VALUES
(1, 0, 'YES','YES',1,'C1'),
(2, 0, 'YES','NO',1,'S1'),
(3, 0, 'YES','YES',2,'C1'),
(4, 0, 'NO','NO',2,'B1'),
(5, 0, 'YES','YES',2,'S2');

select * from customer;
select * from product;
select * from orders;
update product set pcode='C1' where pcode='T1'; -- 같이 변경됨 product와 orders가!
update orders set orderprice='1500000' where pcode='B1'; -- 같이 변경됨 product와 orders가!
update orders set orderprice='600000' where pcode='C1'; -- 같이 변경됨 product와 orders가!
update orders set orderprice='800000' where pcode='S1'; -- 같이 변경됨 product와 orders가!
update orders set orderprice='400000' where pcode='S2'; -- 같이 변경됨 product와 orders가!

select PAYCHECK as '입금확인', DELIVERCK as '배송완료여부', orderprice as '가격',(select pname from product where pprice=orderprice) as '상품명'
from orders
where cusnum=(select cusnum from customer where cusnum=1); -- 코드1번 손님의 주문내용
