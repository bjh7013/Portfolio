package com.ssafy.hello;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/product.do")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	static class Save {
		String name;
		int price;
		String info;

		public Save(String name, int price, String info) {
			super();
			this.name = name;
			this.price = price;
			this.info = info;
		}

	}

	static List<Save> list = new LinkedList<>();

//	protected void service(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		System.out.println();
//	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pname = null;
		String pinfo = null;
		int pprice = 0;
		int pindex = 0;
		response.setContentType("text/html;charset=utf-8");
		request.getContentType();
		if (request.getParameter("productname") != null) {
			pname = request.getParameter("productname");
		}
		if (request.getParameter("productprice") != null) {
			pprice = Integer.parseInt(request.getParameter("productprice"));
		}
		if (request.getParameter("productinfo") != null) {
			pinfo = request.getParameter("productinfo");
		}
		if (request.getParameter("productindex") != null) {
			pindex = Integer.parseInt(request.getParameter("productindex"));
		}
		String url1 = "/hs/productEnroll.html";
		if (pprice != 0 && pindex==0) { // 등록
			list.add(new Save(pname, pprice, pinfo));
			System.out.println("등록되었습니다 이름 : " + list.get(list.size() - 1).name);
			response.sendRedirect(url1);
		} else if (pname != null && pindex==0) {
//			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("	<body>");
			for (int i = 0; i < list.size(); i++) {
				if (!pname.equals(list.get(i).name))
					continue;
				System.out.println(
						(i + 1) + " " + list.get(i).name + " " + list.get(i).price + " " + list.get(i).info + " ");
				out.println((i + 1) + " " + list.get(i).name + " " + list.get(i).price + " " + list.get(i).info + " ");
				out.println("</br>");
			}
			out.println("	</body>");
			out.println("</html>");
		} else if (pindex == 0 && pprice == 0 && pname == null && pinfo == null) {
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("	<body>");
			for (int i = 0; i < list.size(); i++) {
				System.out.println(
						(i + 1) + " " + list.get(i).name + " " + list.get(i).price + " " + list.get(i).info + " ");
				out.println((i + 1) + " " + list.get(i).name + " " + list.get(i).price + " " + list.get(i).info + " ");
				out.println("</br>");
			}
			out.println("	</body>");
			out.println("</html>");
		} else if (pindex > 0 && pprice > 0) {
			System.out.println("oo");
			PrintWriter out = response.getWriter();
			list.get(pindex-1).name = pname;
			list.get(pindex-1).price = pprice;
			list.get(pindex-1).info = pinfo;
			out.println("<html>");
			out.println("	<body> update complete!");
			out.println("	</body>");
			out.println("</html>");
		} else if (pindex > 0) {
			if(list.isEmpty())
				return;
			list.remove(pindex-1);
		}
	}

}
