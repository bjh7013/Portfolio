package productmanager.dto;

public class ProductManagerDTO {
	private String Pname;
	private int Pprice;
	private String Pinfo;
	private String Pbrand;
	public ProductManagerDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductManagerDTO(String pname, int pprice, String pinfo, String pbrand) {
		super();
		Pname = pname;
		Pprice = pprice;
		Pinfo = pinfo;
		Pbrand = pbrand;
	}
	public String getPname() {
		return Pname;
	}
	public void setPname(String pname) {
		Pname = pname;
	}
	public int getPprice() {
		return Pprice;
	}
	public void setPprice(int pprice) {
		Pprice = pprice;
	}
	public String getPinfo() {
		return Pinfo;
	}
	public void setPinfo(String pinfo) {
		Pinfo = pinfo;
	}
	public String getPbrand() {
		return Pbrand;
	}
	public void setPbrand(String pbrand) {
		Pbrand = pbrand;
	}
	
	
}
