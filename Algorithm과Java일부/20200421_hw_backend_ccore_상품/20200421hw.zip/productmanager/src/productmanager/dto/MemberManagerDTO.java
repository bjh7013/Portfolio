package productmanager.dto;

public class MemberManagerDTO {
	private String memberid;
	private String memberpw;
	private String membername;
	private String memberaddr; // 이메일주소
	private String membernumber; //휴대폰번호
	public MemberManagerDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MemberManagerDTO(String memberid, String memberpw, String membername, String memberaddr,
			String membernumber) {
		super();
		this.memberid = memberid;
		this.memberpw = memberpw;
		this.membername = membername;
		this.memberaddr = memberaddr;
		this.membernumber = membernumber;
	}
	public String getMemberid() {
		return memberid;
	}
	public void setMemberid(String memberid) {
		this.memberid = memberid;
	}
	public String getMemberpw() {
		return memberpw;
	}
	public void setMemberpw(String memberpw) {
		this.memberpw = memberpw;
	}
	public String getMembername() {
		return membername;
	}
	public void setMembername(String membername) {
		this.membername = membername;
	}
	public String getMemberaddr() {
		return memberaddr;
	}
	public void setMemberaddr(String memberaddr) {
		this.memberaddr = memberaddr;
	}
	public String getMembernumber() {
		return membernumber;
	}
	public void setMembernumber(String membernumber) {
		this.membernumber = membernumber;
	}
	
	
	
	
}
