package productmanager.service;

import java.util.List;

import productmanager.dao.ProductManagerDAO;
import productmanager.dao.ProductManagerDAOImpl;
import productmanager.dto.ProductManagerDTO;

public class ProductManagerServiceImpl implements ProductManagerService{
	private ProductManagerDAO productmanagerDAO;
	public ProductManagerServiceImpl() {
		 productmanagerDAO = new ProductManagerDAOImpl();
	}
	@Override
	public void enrollProduct(ProductManagerDTO productManagerDTO) throws Exception {
		if(productManagerDTO.getPname() == null ||productManagerDTO.getPprice() == 0 || productManagerDTO.getPinfo() == null) {
			throw new Exception();
		}
		productmanagerDAO.enrollProduct(productManagerDTO);
	}

	@Override
	public void modifyProduct(ProductManagerDTO productManagerDTO) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProduct(ProductManagerDTO productManagerDTO) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ProductManagerDTO> searchAllProduct() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProductManagerDTO searchProduct(String productname) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
