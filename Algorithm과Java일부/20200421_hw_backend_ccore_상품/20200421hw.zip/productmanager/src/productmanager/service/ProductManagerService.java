package productmanager.service;

import java.sql.SQLException;
import java.util.List;

import productmanager.dto.ProductManagerDTO;

public interface ProductManagerService {
	public void enrollProduct(ProductManagerDTO productManagerDTO) throws Exception;
	public void modifyProduct(ProductManagerDTO productManagerDTO) throws Exception;
	public void deleteProduct(ProductManagerDTO productManagerDTO) throws Exception;
	public List<ProductManagerDTO> searchAllProduct() throws Exception;
	public ProductManagerDTO searchProduct(String productname) throws Exception;
}
