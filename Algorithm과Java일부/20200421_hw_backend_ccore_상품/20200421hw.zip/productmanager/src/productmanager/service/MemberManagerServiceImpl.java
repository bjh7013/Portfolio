package productmanager.service;

import java.util.List;


import productmanager.dao.MemberManagerDAO;
import productmanager.dao.MemberManagerDAOImpl;
import productmanager.dto.MemberManagerDTO;

public class MemberManagerServiceImpl implements MemberManagerService{
	private MemberManagerDAO memberManagerDAO;
	public MemberManagerServiceImpl() {
		memberManagerDAO = new MemberManagerDAOImpl();
	}

	@Override
	public void createMember(MemberManagerDTO memberManagerDTO) throws Exception {
		if(memberManagerDTO.getMemberid() == null || memberManagerDTO.getMemberpw() == null || memberManagerDTO.getMembername() == null) {
			throw new Exception();
		}
		memberManagerDAO.createMember(memberManagerDTO);
	}

	@Override
	public MemberManagerDTO joinMember(MemberManagerDTO memberManagerDTO) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modifyMember(MemberManagerDTO memberManagerDTO) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delelteMember(MemberManagerDTO memberManagerDTO) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<MemberManagerDTO> searchAllMember() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MemberManagerDTO searchMember(String memberid) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
