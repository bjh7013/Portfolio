package productmanager.service;

import java.sql.SQLException;
import java.util.List;

import productmanager.dto.MemberManagerDTO;

public interface MemberManagerService {
	public void createMember(MemberManagerDTO memberManagerDTO) throws Exception;
	public MemberManagerDTO joinMember(MemberManagerDTO memberManagerDTO) throws Exception;
	public void modifyMember(MemberManagerDTO memberManagerDTO) throws Exception;
	public void delelteMember(MemberManagerDTO memberManagerDTO) throws Exception;
	public List<MemberManagerDTO> searchAllMember() throws Exception;
	public MemberManagerDTO searchMember(String memberid) throws Exception;
}
