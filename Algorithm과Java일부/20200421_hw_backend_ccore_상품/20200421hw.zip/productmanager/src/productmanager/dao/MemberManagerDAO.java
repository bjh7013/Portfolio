package productmanager.dao;

import java.sql.SQLException;
import java.util.List;

import productmanager.dto.MemberManagerDTO;

public interface MemberManagerDAO {
	public void createMember(MemberManagerDTO memberManagerDTO) throws SQLException;
	public MemberManagerDTO joinMember(MemberManagerDTO memberManagerDTO) throws SQLException;
	public void modifyMember(MemberManagerDTO memberManagerDTO) throws SQLException;
	public void delelteMember(MemberManagerDTO memberManagerDTO) throws SQLException;
	public List<MemberManagerDTO> searchAllMember() throws SQLException;
	public MemberManagerDTO searchMember(String memberid) throws SQLException;
}
