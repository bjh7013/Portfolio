package productmanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import productmanager.dto.ProductManagerDTO;
import productmanager.util.DBUtil;

public class ProductManagerDAOImpl implements ProductManagerDAO {

	@Override
	public void enrollProduct(ProductManagerDTO productManagerDTO) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("insert into product (pname, pprice, pinfo, pbrand) \n");
			insertMember.append("VALUES(?,?,?,?)");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, productManagerDTO.getPname());
			pstmt.setInt(2, productManagerDTO.getPprice());
			pstmt.setString(3, productManagerDTO.getPinfo());
			pstmt.setString(4, productManagerDTO.getPbrand());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}

	}

	@Override
	public void modifyProduct(ProductManagerDTO productManagerDTO) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteProduct(ProductManagerDTO productManagerDTO) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public List<ProductManagerDTO> searchAllProduct() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProductManagerDTO searchProduct(String productname) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
