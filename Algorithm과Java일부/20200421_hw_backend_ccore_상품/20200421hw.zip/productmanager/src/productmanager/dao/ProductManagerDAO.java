package productmanager.dao;

import java.sql.SQLException;
import java.util.List;

import productmanager.dto.ProductManagerDTO;

public interface ProductManagerDAO {
	public void enrollProduct(ProductManagerDTO productManagerDTO) throws SQLException;
	public void modifyProduct(ProductManagerDTO productManagerDTO) throws SQLException;
	public void deleteProduct(ProductManagerDTO productManagerDTO) throws SQLException;
	public List<ProductManagerDTO> searchAllProduct() throws SQLException;
	public ProductManagerDTO searchProduct(String productname) throws SQLException;
}
