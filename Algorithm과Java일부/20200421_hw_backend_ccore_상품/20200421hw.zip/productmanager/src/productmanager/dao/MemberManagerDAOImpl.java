package productmanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import productmanager.dto.MemberManagerDTO;
import productmanager.util.DBUtil;

public class MemberManagerDAOImpl implements MemberManagerDAO {

	@Override
	public void createMember(MemberManagerDTO memberManagerDTO) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("insert into member (memberid, memberpw, membername, memberaddr,membernumber) \n");
			insertMember.append("VALUES(?,?,?,?,?)");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, memberManagerDTO.getMemberid());
			pstmt.setString(2, memberManagerDTO.getMemberpw());
			pstmt.setString(3, memberManagerDTO.getMembername());
			pstmt.setString(4, memberManagerDTO.getMemberaddr());
			pstmt.setString(5, memberManagerDTO.getMembernumber());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

	@Override
	public MemberManagerDTO joinMember(MemberManagerDTO memberManagerDTO) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modifyMember(MemberManagerDTO memberManagerDTO) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delelteMember(MemberManagerDTO memberManagerDTO) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<MemberManagerDTO> searchAllMember() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MemberManagerDTO searchMember(String memberid) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
