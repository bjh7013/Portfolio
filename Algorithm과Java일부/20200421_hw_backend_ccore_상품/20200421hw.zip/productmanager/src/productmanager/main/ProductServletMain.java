package productmanager.main;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import productmanager.service.ProductManagerService;


/**
 * Servlet implementation class ProductServletMain
 */
@WebServlet("/productmain.do")
public class ProductServletMain extends HttpServlet {
	private static final long serialVersionUID = 1L;

	static private ProductManagerService productService;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String root = request.getContextPath();
		String act = request.getParameter("act");
		System.out.println(act);
		RequestDispatcher dispatcher;
		if("enroll".equals(act)) {
			dispatcher = request.getRequestDispatcher("productenroll.do");
			dispatcher.forward(request, response);
		} else if("delete".equals(act)) {
			dispatcher = request.getRequestDispatcher("productdelete.do");
			dispatcher.forward(request, response);
		} else if("search".equals(act)) {
			dispatcher = request.getRequestDispatcher("productsearch.do");
			dispatcher.forward(request, response);
		} else if("searchall".equals(act)) {
			dispatcher = request.getRequestDispatcher("productsearchall.do");
			dispatcher.forward(request, response);
		} else if("update".equals(act)) {
			dispatcher = request.getRequestDispatcher("productupdate.do");
			dispatcher.forward(request, response);
		} else {
			response.sendRedirect(root);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
