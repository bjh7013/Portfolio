package productmanager.main;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import productmanager.dto.ProductManagerDTO;
import productmanager.service.ProductManagerService;
import productmanager.service.ProductManagerServiceImpl;

@WebServlet("/productenroll.do")
public class ProductServletEnroll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	public void init() throws ServletException {
		super.init();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("실패");
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String root = request.getContextPath();
		request.setCharacterEncoding("utf-8");
		String path = "/index.jsp";
		ProductManagerDTO productDTO = new ProductManagerDTO();
		productDTO.setPname(request.getParameter("pname"));
		productDTO.setPprice(Integer.parseInt(request.getParameter("pprice")));
		productDTO.setPinfo(request.getParameter("pinfo"));
		productDTO.setPbrand(request.getParameter("pbrand"));
		ProductManagerService productservice = new ProductManagerServiceImpl();
		try {
			productservice.enrollProduct(productDTO);
			path = "/product/productEnroll.jsp";
			request.setAttribute("enrolls", "enrollcomplete");
			forward(request, response, path);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "등록에 실패하였습니다.");
			path = "/error/error.jsp";
			forward(request, response, path);
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}
	private void forward(HttpServletRequest request, HttpServletResponse response, String path) {
		RequestDispatcher dispatcher;
		dispatcher = request.getRequestDispatcher(path);
		try {
			dispatcher.forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
