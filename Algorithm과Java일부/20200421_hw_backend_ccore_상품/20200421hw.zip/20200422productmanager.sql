create database ssafyweb;

use ssafyweb;

DROP TABLE `product`;

-- DROP TABLE `ssafy_member`;

CREATE TABLE `member` (
	`memberno`  int PRIMARY KEY auto_increment,
	`memberid`	VARCHAR(20) 	NOT NULL,
	`memberpw`	VARCHAR(100) 	NOT NULL,
    `membername`	VARCHAR(20) 	NOT NULL,
	`memberaddr`		VARCHAR(2000),
    `membernumber` 	VARCHAR(2000)
);

INSERT INTO `member` (`memberid`, `memberpw`, `membername`, `memberaddr`,`membernumber`)
VALUES('wjdgns', '112233', '백정훈', 'bjh7013@gmail.com','010-9934-5504');

INSERT INTO `member` (`memberid`, `memberpw`, `membername`, `memberaddr`,`membernumber`)
VALUES('ssafy', 'ssafy', '김싸피', 'ssafy@ssafy.com','010-4444-7777');

INSERT INTO `product` (`pname`, `pprice`, `pinfo`, `pbrand`)
VALUES('LG드럼세탁기', 1000000, '돌돌이 잘 돌아갑니다', 'LG');

INSERT INTO `product` (`pname`, `pprice`, `pinfo`, `pbrand`)
VALUES('삼성OLEDTV', 3000000, '화질이 최고입니다.', '삼성');

commit;

CREATE TABLE `product` (
	`pno`  		int PRIMARY KEY auto_increment,
	`pname`		VARCHAR(20) 	NOT NULL,
	`pprice`	int 	NOT NULL,
    `pinfo`		VARCHAR(2000) 	NOT NULL,
	`pbrand`		VARCHAR(20)
);
select * from `member`;
select * from `product`;