package hwdb03_구미_4반_백정훈;

import java.sql.SQLException;
import java.util.ArrayList;

public interface ProductDAO {
//	Create는 이미 만들어져 있으니 안만들겠습니다.
	int insertProduct(Product product) throws SQLException;//정보 추가 기능
	int updateProduct(Product product) throws SQLException;//수정기능
	int deleteProduct(Product product) throws SQLException;//삭제기능
	void selectAllProduct() throws SQLException; // 정보 전체 조회기능
	void selectChoiceProduct(Product product) throws SQLException; // 정보 전체 조회기능
	
	
}
