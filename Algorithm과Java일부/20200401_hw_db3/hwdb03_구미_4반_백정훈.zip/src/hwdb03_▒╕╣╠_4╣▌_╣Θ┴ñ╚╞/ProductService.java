package hwdb03_구미_4반_백정훈;

import java.sql.SQLException;

public interface ProductService { //추후 제작...
	int insertProduct(Product product);
	int updateProduct(Product product);
	int deleteProduct(Product product);
	void selectAllProduct();
}
