package hwdb03_구미_4반_백정훈;

import java.sql.SQLException;

public class ProductTest {
	
	public ProductTest(){
		ProductDAO productdao = new ProductDAOImpl();
		Product product = new Product(4001,"드럼세탁기",3200000);
		Product product2 = new Product(4002,"냉동고",2000000);
		
		try {
			
			productdao.insertProduct(product); //product 내용 삽입
			productdao.updateProduct(product); //product 삽입한 내용 수정
			productdao.deleteProduct(product); //product 삽입한 내용 삭제
			productdao.selectAllProduct(); //product 조회
			productdao.selectChoiceProduct(product2); //product 가격 조회
		} catch (SQLException e) {
		
			System.out.println("실패요");
		}
	}
	public static void main(String[] args) {
		new ProductTest();
	}
}
