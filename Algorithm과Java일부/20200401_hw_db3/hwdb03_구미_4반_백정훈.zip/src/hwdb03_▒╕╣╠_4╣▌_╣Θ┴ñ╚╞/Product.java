package hwdb03_구미_4반_백정훈;

public class Product {
	int pcode;
	int price;
	String pname;
	@Override
	public String toString() {
		return "Product [pcode=" + pcode + ", price=" + price + ", pname=" + pname + "]";
	}


	public int getPcode() {
		return pcode;
	}

	public void setPcode(int pcode) {
		this.pcode = pcode;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Product(int pcode, String pname, int price) {
		super();
		this.pcode = pcode;
		this.pname = pname;
		this.price = price;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
}
