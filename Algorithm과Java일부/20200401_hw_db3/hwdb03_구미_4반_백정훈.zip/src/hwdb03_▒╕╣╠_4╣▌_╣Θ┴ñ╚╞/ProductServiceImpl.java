package hwdb03_구미_4반_백정훈;

import java.sql.SQLException;

public class ProductServiceImpl implements ProductService {

	public int insertProduct(Product product) {

		ProductDAO dao = new ProductDAOImpl();
		int cnt = 0;
		try {
			cnt = dao.insertProduct(product);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;

	}

	public int updateProduct(Product product) {
		ProductDAO dao = new ProductDAOImpl();
		int cnt = 0;
		try {
			cnt = dao.updateProduct(product);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}

	public int deleteProduct(Product product) {
		ProductDAO dao = new ProductDAOImpl();
		int cnt = 0;
		try {
			cnt = dao.deleteProduct(product);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}

	public void selectAllProduct() {
		ProductDAO dao = new ProductDAOImpl();

	}

}
