package hwdb03_구미_4반_백정훈;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ProductDAOImpl implements ProductDAO {

	@Override
	public int insertProduct(Product product) throws SQLException {
//		1. 드라이버 로딩
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("드라이버 로딩 실패");
		}
//		2. 데이터베이스 연결
		String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		String id = "root";
		String pw = "@aA3@aA3@aA3";
		Connection con = DriverManager.getConnection(url, id, pw);
//		3. 스테이트먼트 생성 (Prepared) - insert
		int pcode = product.pcode;
		String pname = product.pname;
		int price = product.price;
//		int pcode = 1004;
//		String pname = "QLEDTV";
//		int price = 1000001;
		String sql ="insert into product(pcode,pname,price) values(?,?,?)";
//		String sql2 ="insert into(pcode,pname,price) product values(1004,'QLEDTV',100000)";
		PreparedStatement pSt = con.prepareStatement(sql);

		pSt.setInt(1, pcode);   
		pSt.setString(2, pname);   
		pSt.setInt(3, price);   
		pSt.executeUpdate();
		
		pSt.close();
		con.close();
		return 0;
	}

	@Override
	public int updateProduct(Product product) throws SQLException {
//		1. 드라이버 로딩
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		2. 데이터베이스 연결
		Connection con = null;
		String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		String id = "root";
		String pw = "@aA3@aA3@aA3";
		con = DriverManager.getConnection(url, id, pw);
//		3. 스테이트먼트 생성 (Prepared) - update
		PreparedStatement pSt = null;
		int price = 1500000;
		String sql ="update product set price=? where pcode=?"; // pcode product 받은 데이터 일 때 price가격 변경
		pSt = con.prepareStatement(sql);
		pSt.setInt(1, price);
		pSt.setInt(2, product.pcode);   
		pSt.executeUpdate();
		
		con.close();
		return 0;
	}
	
	@Override
	public int deleteProduct(Product product) throws SQLException {
//		1. 드라이버 로딩
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		2. 데이터베이스 연결
		Connection con = null;
		String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		String id = "root";
		String pw = "@aA3@aA3@aA3";
		con = DriverManager.getConnection(url, id, pw);
//		3. 스테이트먼트 생성 (Prepared) - delete
		PreparedStatement pSt = null;
		String sql ="delete from product where pcode=?"; // 받은 code로 지움.
		pSt = con.prepareStatement(sql);
		pSt.setInt(1, product.pcode);   
		pSt.executeUpdate();
		
		con.close();
		return 0;
	}

	public void selectAllProduct() throws SQLException{
//		1. 드라이버 로딩
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		2. 데이터베이스 연결
		Connection con = null;
		String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		String id = "root";
		String pw = "@aA3@aA3@aA3";
		con = DriverManager.getConnection(url,id,pw);
//		con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8","root","@aA3@aA3@aA3");
//		3. 스테이트먼트 생성 (Prepared)
		Statement stm = null;
		String sql ="select * from product"; // 전체 검색
		stm = con.createStatement();
//		4. 데이터 조회
		ResultSet rs = stm.executeQuery(sql);
		
		while(rs.next()) {
			System.out.println(rs.getInt("pcode")+" "+rs.getString("pname")+" "+rs.getInt("price"));
		}
		con.close();
	}

	@Override
	public void selectChoiceProduct(Product product) throws SQLException {
//		1. 드라이버 로딩
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		2. 데이터베이스 연결
		Connection con = null;
		String url = "jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		String id = "root";
		String pw = "@aA3@aA3@aA3";
		con = DriverManager.getConnection(url,id,pw);
//		con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8","root","@aA3@aA3@aA3");
//		3. 스테이트먼트 생성 (Prepared)
		Statement stm = null;
		String sql ="select * from product where price>="+product.price; // 전체 검색
		stm = con.createStatement();
//		4. 데이터 조회
		ResultSet rs = stm.executeQuery(sql);
		
		while(rs.next()) {
			System.out.println(rs.getInt("pcode")+" "+rs.getString("pname")+" "+rs.getInt("price"));
		}
		con.close();
		
	}





}
