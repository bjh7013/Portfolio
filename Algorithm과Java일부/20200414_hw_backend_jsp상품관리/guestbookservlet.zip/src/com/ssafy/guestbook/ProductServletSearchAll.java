package com.ssafy.guestbook;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProductServletSearchAll
 */
@WebServlet("/productsearchall.do")
public class ProductServletSearchAll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	public void init() throws ServletException {
		super.init();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("실패");
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		Statement stm = null;
		try {
			conn = DriverManager.getConnection(
					"jdbc:mysql://192.168.0.149:3306/ssafyweb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8",
					"root", "1234");
			String insertMember = "select * from product";
			stm = conn.createStatement();
			rst = stm.executeQuery(insertMember);
			PrintWriter out = response.getWriter();
			response.setContentType("text/html;charset=utf-8");
			out.println("<META http-equiv=\"Content-Type\" content=\"text/html;charset=utf-8\">");
			out.println("<html>");
			out.println("	<body>");
			out.println("	<div align=\"center\">");
			while (rst.next()) {
				out.print(rst.getInt("no") + " " + rst.getString("name") + " " + rst.getInt("price") + " "
						+ rst.getString("info") + "</br>");
			}
			out.println(" <a href=\"/guestbookservlet/totalProduct.jsp\">Main</a>");
			out.println("	</div>");
			out.println("	</body>");
			out.println("</html>");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
