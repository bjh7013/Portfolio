

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class AptDealHistoryDom {

    public static void main(String[] args) {

        File file = new File("./src/AptDealHistory.xml");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        
        try {
        	
        	builder = factory.newDocumentBuilder();
            Document doc = builder.parse(file);
            doc.getDocumentElement().normalize();
            Element root = doc.getDocumentElement();
            System.out.println("Root element : " + root.getNodeName());
            
            NodeList nodeList = doc.getElementsByTagName("item");

            List<AptDealHistory> AptList = new ArrayList<AptDealHistory>();
            
            for (int i = 0; i < nodeList.getLength(); i++) {
            	Node node = nodeList.item(i);
            	if (node.getNodeType() == Node.ELEMENT_NODE) {
            		Element element = (Element) node;
 
            		String cost = element.getElementsByTagName("거래금액").item(0).getTextContent();
            		String buildyear = element.getElementsByTagName("건축년도").item(0).getTextContent();
            		String year = element.getElementsByTagName("년").item(0).getTextContent();
            		String loc = element.getElementsByTagName("법정동").item(0).getTextContent();
            		String apt = element.getElementsByTagName("아파트").item(0).getTextContent();
            		String month = element.getElementsByTagName("월").item(0).getTextContent();
            		String day = element.getElementsByTagName("일").item(0).getTextContent();
            		String size = element.getElementsByTagName("전용면적").item(0).getTextContent();
            		String add = element.getElementsByTagName("지번").item(0).getTextContent();
            		String code = element.getElementsByTagName("지역코드").item(0).getTextContent();
            		String floor = element.getElementsByTagName("층").item(0).getTextContent();
            		
        			AptDealHistory emp = new AptDealHistory();
        			emp.setCost(cost);
        			emp.setBuildyear(buildyear);
        			emp.setYear(year);
        			emp.setLoc(loc);
        			emp.setApt(apt);
        			emp.setMonth(month);
        			emp.setDay(day);
        			emp.setSize(size);
        			emp.setAdd(add);
        			emp.setCode(code);
        			emp.setFloor(floor);
        			
        			AptList.add(emp);
            	}
            }

            for (AptDealHistory Apt : AptList) {
                System.out.println(Apt);
            }
        } catch (SAXException | ParserConfigurationException | IOException e1) {
            e1.printStackTrace();
        }

    }
}