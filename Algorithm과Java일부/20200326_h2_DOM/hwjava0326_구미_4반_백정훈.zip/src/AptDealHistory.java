

public class AptDealHistory {

	public String getCost() {
		return cost;
	}



	public void setCost(String cost) {
		this.cost = cost;
	}



	public String getBuildyear() {
		return buildyear;
	}



	public void setBuildyear(String buildyear) {
		this.buildyear = buildyear;
	}



	public String getYear() {
		return year;
	}



	public void setYear(String year) {
		this.year = year;
	}



	public String getLoc() {
		return loc;
	}



	public void setLoc(String loc) {
		this.loc = loc;
	}



	public String getApt() {
		return apt;
	}



	public void setApt(String apt) {
		this.apt = apt;
	}



	public String getMonth() {
		return month;
	}



	public void setMonth(String month) {
		this.month = month;
	}



	public String getDay() {
		return day;
	}



	public void setDay(String day) {
		this.day = day;
	}



	public String getSize() {
		return size;
	}



	public void setSize(String size) {
		this.size = size;
	}



	public String getAdd() {
		return add;
	}



	public void setAdd(String add) {
		this.add = add;
	}



	public String getCode() {
		return code;
	}



	public void setCode(String code) {
		this.code = code;
	}



	public String getFloor() {
		return floor;
	}



	public void setFloor(String floor) {
		this.floor = floor;
	}



	private String cost;
    private String buildyear;
    private String year;
    private String loc;
    private String apt;
    private String month;
    private String day;
    private String size;
    private String add;
    private String code;
    private String floor;
    
    
    public AptDealHistory() {
		super();
		// TODO Auto-generated constructor stub
	}



	@Override
    public String toString() {
    	StringBuilder builder = new StringBuilder();
		builder.append("AptDealHistory [cost=");
		builder.append(cost);
		builder.append(", Buildyear=");
		builder.append(buildyear);
		builder.append(", year=");
		builder.append(year);
		builder.append(", location=");
		builder.append(loc);
		builder.append(", Aptname=");
		builder.append(apt);
		builder.append(", Month=");
		builder.append(month);
		builder.append(", Day=");
		builder.append(day);
		builder.append(", Size=");
		builder.append(size);
		builder.append(", Address=");
		builder.append(add);
		builder.append(", Code=");
		builder.append(code);
		builder.append(", Floor=");
		builder.append(floor);
		builder.append("]");
		return builder.toString();
    }
    
}
