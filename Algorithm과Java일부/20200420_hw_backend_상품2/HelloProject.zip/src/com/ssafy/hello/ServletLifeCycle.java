package com.ssafy.hello;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/lifecycle.do")
public class ServletLifeCycle implements Servlet {
	private static final long serialVersionUID = 1L;

	static int num = 0;
	static int cnt = 0;
	public ServletLifeCycle() {
		System.out.println("ServletLifeCycle() call!!!");
	}

	@Override
	public void destroy() {
		System.out.println("destroy() call!!!");
	}

	@Override
	public ServletConfig getServletConfig() {
		System.out.println("getServletConfig() call!!!");
		return null;
	}

	@Override
	public String getServletInfo() {
		System.out.println("getServletConfig call!!!");
		return null;
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init(ServletConfig config) call!!!");
		int num = 0;
		num++;
		System.out.println(num);
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		System.out.println("service(ServletRequest req, ServletResponse res) call!!!");
		res.getWriter().print("Console View!!!!");
		num++;
		cnt++;
		System.out.println("cnt : " + cnt + "num : " + num);
	}

}
