import java.util.Scanner;

public class HW1 {
	public static void main(String[] args) {
		int T;
		Scanner sc = new Scanner(System.in);
		T = sc.nextInt();
		int stu=1000;
		int[] scot = new int[101];
		int[] num = new int[T];
			int temp;
		int[] scott = new int[T];
		int temp2=0;
			
		for(int i=0;i<T;i++) {
			int[] sco = new int[101];
			sco[0] = 0;
			temp2=0;
			num[i]=sc.nextInt(); // n번째
			for(int j=0;j<stu;j++) {
				temp=sc.nextInt();
				sco[temp]++;
			}
			temp=0;
			for(int j=0;j<sco.length;j++) {
				if(temp<sco[j]) //값<빈도
				{
					temp=sco[j];//
					scot[i]=j;//scot에 값넣기
				}
				if(temp==sco[j]) {
					if(scot[i]<j) {
						temp=sco[j];//
						scot[i]=j;//scot에 값넣기
					}
				}
				
			}
		}
		
		for(int i=0;i<T;i++) {
			System.out.println("#" + num[i] +" "+ scot[i]);
		}
	}
}
