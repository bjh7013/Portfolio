package virus;

public class Corona extends Virus{
	private String spreadSpeed;
	private String bigo;

	public String getBigo() {
		return bigo;
	}

	public void setBigo(String bigo) {
		this.bigo = bigo;
	}

	public Corona(String name, int level, String spreadSpeed, String bigo) {
		super(name, level);
		this.spreadSpeed = spreadSpeed;
		this.bigo = bigo;
	}

	public String getSpreadSpeed() {
		return spreadSpeed;
	}

	public void setSpreadSpeed(String spreadSpeed) {
		this.spreadSpeed = spreadSpeed;
	}

	public Corona(String name, int level, String spreadSpeed) {
		super(name, level);
		this.spreadSpeed = spreadSpeed;
	}

	public Corona() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Corona(String name, int level) {
		super(name, level);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Corona [spreadSpeed=" + spreadSpeed + "]";
	}
}
