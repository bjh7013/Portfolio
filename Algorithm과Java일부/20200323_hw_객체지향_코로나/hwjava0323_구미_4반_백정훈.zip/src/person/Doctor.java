package person;

public class Doctor extends Person {
	private String hospitalId;
	private String licenseId;
	@Override
	public String toString() {
		return "Doctor [hospitalId=" + hospitalId + ", licenseId=" + licenseId + "]";
	}
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Doctor(String name, int age, String phone, boolean sex) {
		super(name, age, phone, sex);
		// TODO Auto-generated constructor stub
	}
	public Doctor(String name, int age, String phone) {
		super(name, age, phone);
		// TODO Auto-generated constructor stub
	}
	public Doctor(String name, int age, String phone, boolean sex, String hospitalId, String licenseId) {
		super(name, age, phone, sex);
		this.hospitalId = hospitalId;
		this.licenseId = licenseId;
	}
	public String getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getLicenseId() {
		return licenseId;
	}
	public void setLicenseId(String licenseId) {
		this.licenseId = licenseId;
	}
	
}
